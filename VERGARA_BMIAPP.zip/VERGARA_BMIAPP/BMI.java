import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;


public class BMI extends javax.swing.JFrame {
BMI() {
JFrame f = new JFrame();

JLabel lb1 = new JLabel("(Height)");
lb1.setBounds(20, 10, 100, 40);
f.add(lb1); 

JLabel lb2 = new JLabel("(Inches):");
lb2.setBounds(20, 50, 100, 40);
f.add(lb2); 

JLabel lb3 = new JLabel("Weight(Pounds):");
lb3.setBounds(20, 90, 100, 40);
f.add(lb3); 

JLabel lbResult = new JLabel("NATHANIEL VERGARA'S BMI APPLICATION");
lbResult.setBounds(20, 160, 300, 40);
f.add(lbResult); 
JTextField txtHeight = new JTextField("");
txtHeight.setBounds(120, 10, 200, 40);
f.add(txtHeight); 

JTextField txtInch = new JTextField("");
txtInch.setBounds(120, 50, 200, 40);
f.add(txtInch);

JTextField txtWeight = new JTextField("");
txtWeight.setBounds(120, 90, 200, 40);
f.add(txtWeight); 

JButton btn = new JButton("CLICK TO CHECK YOUR BMI");
btn.setBounds(20, 200, 300, 40);


btn.addActionListener(new ActionListener(){

public void actionPerformed(ActionEvent e) {

double weight=Double.parseDouble(txtWeight.getText());
double height=Double.parseDouble(txtHeight.getText());
double inch=Double.parseDouble(txtInch.getText());

double bmi = weight / (height) * 703 / 1000;

if (bmi < 18.5) {
lbResult.setText("underweight - BMI : "+bmi);
} else if (bmi < 25) {
lbResult.setText("normal - BMI : "+bmi);
} else if (bmi < 30) {
lbResult.setText("overweight - BMI : "+bmi);
} else {
lbResult.setText("obese - BMI : "+bmi);
}
}
});

f.add(btn);

f.setSize(400, 300);
f.setLayout(null);
f.setVisible(true);

}

public static void main(String[] args) {
new BMI();
}
}